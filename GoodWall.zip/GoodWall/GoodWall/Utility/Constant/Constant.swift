//
//  Constant.swift
//  GoodWall
//
//  Created by Keith Gapusan on 07/08/2018.
//  Copyright © 2018 Keith Gapusan. All rights reserved.
//

import UIKit

class Constant: NSObject {

    public static let dev = "https://restcountries.eu/rest/v2/all"
    public static let staging = "https://restcountries.eu/rest/v2/all"
    public static let live = "https://restcountries.eu/rest/v2/all"
    public static let baseUrl = dev

    
}
